import Image from "next/image";

export default function Home() {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center text-white">
      {/* Background */}
      <div className="absolute inset-0">
        <Image
          src="public/monastery-bg.jpg" // place your bg image inside public/
          alt="Sikkim Monastery"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/40" /> {/* Dark overlay */}
      </div>

      {/* Hero Content */}
      <main className="relative z-10 text-center px-6">
        <h1 className="text-4xl md:text-6xl font-bold">
          SIKKIM MONASTIC VOYAGES
        </h1>
        <p className="text-lg md:text-2xl italic mt-4">
          A Journey of Serenity & Discovery
        </p>

        {/* Feature Buttons */}
        <div className="flex flex-wrap gap-4 justify-center mt-8">
          <button className="px-4 py-2 bg-white/20 rounded-lg backdrop-blur-md hover:bg-white/30">
            🌐 Multilingual Support
          </button>
          <button className="px-4 py-2 bg-white/20 rounded-lg backdrop-blur-md hover:bg-white/30">
            🙏 Prayer Wall
          </button>
          <button className="px-4 py-2 bg-white/20 rounded-lg backdrop-blur-md hover:bg-white/30">
            🗺 Maps & Routes
          </button>
          <button className="px-4 py-2 bg-white/20 rounded-lg backdrop-blur-md hover:bg-white/30">
            📅 Cultural Calendar
          </button>
        </div>

        {/* Search */}
        <div className="mt-10 flex justify-center">
          <input
            type="text"
            placeholder="Search Monasteries..."
            className="px-4 py-2 rounded-l-lg w-64 text-black"
          />
          <button className="bg-blue-600 px-4 py-2 rounded-r-lg">
            GO
          </button>
        </div>

        {/* Bottom Icons */}
        <div className="mt-12 flex flex-wrap justify-center gap-6">
          <div className="flex flex-col items-center">
            <span className="text-2xl">🕶</span>
            <span>VR 360° View</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-2xl">📸</span>
            <span>Connect</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-2xl">🖼</span>
            <span>Gallery</span>
          </div>
        </div>
      </main>
    </div>
  );
}
